//
//  DSTRecord.swift
//  ZohoCRMClient
//
//  Created by praveen-14637 on 17/09/25.
//  Copyright © 2025 Zoho. All rights reserved.
//
import Foundation

struct DSTRecord: Hashable {
    let recordName: String
    let dateTime: String
    let utcDateTime: String
    let date: String
    let isDST: String
    let timezoneName: String
    let bufferMins: Int
    let gmt: Int
}
