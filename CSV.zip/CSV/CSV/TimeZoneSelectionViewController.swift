//
//  TimezoneSectionViewController.swift
//  ZohoCRMClient
//
//  Created by praveen-14637 on 17/09/25.
//  Copyright © 2025 Zoho. All rights reserved.
//
import Foundation
import UIKit

// MARK: - TimeZoneSelectionDelegate
protocol TimeZoneSelectionDelegate: AnyObject {
    func timeZoneSelectionDidComplete(selectedZones: [String])
}

// MARK: - TimeZoneSelectionViewController
final class TimeZoneSelectionViewController: UITableViewController, UISearchResultsUpdating {
    private let zones: [String] = TimeZone.knownTimeZoneIdentifiers.sorted()
    private var filteredZones: [String] = []
    private var selectedZones: Set<String>
    private var searchController: UISearchController!
    weak var delegate: TimeZoneSelectionDelegate?
    
    init(initialSelected: Set<String> = []) {
        self.selectedZones = initialSelected
        super.init(style: .insetGrouped)
    }
    
    required init?(coder: NSCoder) { fatalError("init(coder:) not supported") }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Select Time Zones"
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "tzCell")
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(doneTapped))
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(cancelTapped))
        
        searchController = UISearchController(searchResultsController: nil)
        searchController.searchResultsUpdater = self
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchBar.placeholder = "Search Time Zones"
        navigationItem.searchController = searchController
        definesPresentationContext = true
        
        filteredZones = zones
    }
    
    @objc private func doneTapped() {
        delegate?.timeZoneSelectionDidComplete(selectedZones: Array(selectedZones))
        if let nav = navigationController, nav.viewControllers.count > 1 {
            navigationController?.popViewController(animated: true)
        } else {
            dismiss(animated: true)
        }
    }
    
    @objc private func cancelTapped() {
        if let nav = navigationController, nav.viewControllers.count > 1 {
            navigationController?.popViewController(animated: true)
        } else {
            dismiss(animated: true)
        }
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int { 1 }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredZones.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let tz = filteredZones[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "tzCell", for: indexPath)
        cell.textLabel?.text = tz
        cell.accessoryType = selectedZones.contains(tz) ? .checkmark : .none
        cell.selectionStyle = .default
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let tz = filteredZones[indexPath.row]
        if selectedZones.contains(tz) {
            selectedZones.remove(tz)
        } else {
            selectedZones.insert(tz)
        }
        tableView.reloadRows(at: [indexPath], with: .automatic)
    }
    
    func updateSearchResults(for searchController: UISearchController) {
        let query = searchController.searchBar.text?.lowercased() ?? ""
        if query.isEmpty {
            filteredZones = zones
        } else {
            filteredZones = zones.filter { $0.lowercased().contains(query) }
        }
        tableView.reloadData()
    }
}
