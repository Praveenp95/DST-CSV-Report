//
//  CSVReportsViewController.swift
//  ZohoCRMClient
//
//  Created by praveen-14637 on 22/08/25.
//  Copyright © 2025 Zoho. All rights reserved.
//
import Foundation
import UIKit

class CSVReportsViewController: UITableViewController {
    
    // MARK: - Properties
    lazy var allZonesSwitch: UISwitch = {
        let zoneSwitch = UISwitch()
        zoneSwitch.isOn = true
        zoneSwitch.addTarget(self, action: #selector(allZonesToggled(_:)), for: .valueChanged)
        return zoneSwitch
    }()
    
    lazy var startYearField = {
        let field = UITextField()
        configureTextField(field, placeholder: "YYYY", text: String(Calendar(identifier: .gregorian).component(.year, from: Date())))
        return field
    }()
    
    lazy var endYearField = {
        let field = UITextField()
        configureTextField(field, placeholder: "YYYY", text: String(Calendar(identifier: .gregorian).component(.year, from: Date())))
        return field
    }()
    
    lazy var bufferField = {
        let field = UITextField()
        configureTextField(field, placeholder: "X", text: "2")
        return field
    }()
    
    private var selectedZones: Set<String> = []
    private let allZones = TimeZone.knownTimeZoneIdentifiers.sorted()
    
    // MARK: - Lifecycle
    override init(style: UITableView.Style = .insetGrouped) {
        super.init(style: style)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "CSV Report"
        addTapGesture()
        tableView.register(SettingsTableViewCell.self, forCellReuseIdentifier: SettingsTableViewCell.reuseIdentifier)
    }
    
    // MARK: - Private Methods
    private func addTapGesture() {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboardAction))
        tapGesture.cancelsTouchesInView = false
        view.addGestureRecognizer(tapGesture)
    }
    
    private func configureTextField(_ textField: UITextField, placeholder: String, text: String) {
        textField.placeholder = placeholder
        textField.text = text
        textField.borderStyle = .roundedRect
        textField.layer.borderWidth = 1.0
        textField.layer.cornerRadius = 6.0
        textField.textColor = .label
        textField.textAlignment = .center
        textField.keyboardType = .numberPad
        textField.layer.borderColor = UIColor.tertiaryLabel.cgColor
        textField.backgroundColor = .secondarySystemBackground
        textField.tintColor = .systemBlue
    }
    
    @objc private func dismissKeyboardAction() {
        view.endEditing(true)
    }
    
    @objc private func allZonesToggled(_ sender: UISwitch) {
        tableView.reloadRows(at: [IndexPath(row: 3, section: 0)], with: .none)
    }
    
    private func presentTimeZoneSelection() {
        let tzVC = TimeZoneSelectionViewController(initialSelected: selectedZones)
        tzVC.delegate = self
        
        if let nav = navigationController {
            nav.pushViewController(tzVC, animated: true)
        } else {
            let nav = UINavigationController(rootViewController: tzVC)
            nav.modalPresentationStyle = .pageSheet
            present(nav, animated: true)
        }
    }
    
    private func showError(_ message: String) {
        DispatchQueue.main.async {
            let a = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
            a.addAction(UIAlertAction(title: "OK", style: .default))
            self.present(a, animated: true)
        }
    }
}

// MARK: - DST Report Generation
extension CSVReportsViewController {
    func generateDSTReport(for range: ClosedRange<Int>, timeZoneIDs: [String], allTimeZones: Bool, buffer: ClosedRange<Int>) -> [DSTRecord] {
        var records: [DSTRecord] = []
        let calendar = Calendar(identifier: .gregorian)
        
        let localFormatter = DateFormatter()
        localFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss ZZZZ"
        
        let utcFormatter = DateFormatter()
        utcFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss ZZZZ"
        utcFormatter.timeZone = TimeZone(secondsFromGMT: 0)
        
        let dateOnlyFormatter = DateFormatter()
        dateOnlyFormatter.dateFormat = "MM/dd/yy"
        
        let targetZones = allTimeZones ? allZones : timeZoneIDs
        
        for timeZoneID in targetZones {
            guard let tz = TimeZone(identifier: timeZoneID) else { continue }
            
            localFormatter.timeZone = tz
            dateOnlyFormatter.timeZone = tz
            
            for year in range {
                guard let startOfYear = calendar.date(from: DateComponents(year: year, month: 1, day: 1)),
                      let endOfYear = calendar.date(from: DateComponents(year: year + 1, month: 1, day: 1)) else {
                    continue
                }
                
                var checkDate = startOfYear
                var transitions: [(date: Date, started: Bool)] = []
                
                while let transition = tz.nextDaylightSavingTimeTransition(after: checkDate),
                      transition < endOfYear {
                    let before = transition.addingTimeInterval(-60)
                    let after = transition.addingTimeInterval(60)
                    
                    if tz.isDaylightSavingTime(for: before) != tz.isDaylightSavingTime(for: after) {
                        transitions.append((transition, tz.isDaylightSavingTime(for: after)))
                    }
                    checkDate = transition.addingTimeInterval(60)
                }
                
                for t in transitions {
                    let startedOrEnded = t.started ? "Daylight Saving Time Started" : "Daylight Saving Time Ended"
                    
                    for offset in buffer {
                        let date = t.date.addingTimeInterval(Double(offset) * 60.0)
                        let dstFlag = tz.isDaylightSavingTime(for: date) ? "TRUE" : "FALSE"
                        let gmtOffsetHours = tz.secondsFromGMT(for: date) / 3600
                        
                        let recordName = "TimeZone: \(timeZoneID): DST=\(dstFlag): GMT\(gmtOffsetHours >= 0 ? "+" : "")\(gmtOffsetHours): \(startedOrEnded) [\(offset >= 0 ? "+" : "")\(offset) min]"
                        
                        let localShort = localFormatter.string(from: date)
                        let utcString = utcFormatter.string(from: date)
                        let dateOnly = dateOnlyFormatter.string(from: date)
                        
                        records.append(DSTRecord(recordName: recordName,
                                                 dateTime: localShort,
                                                 utcDateTime: utcString,
                                                 date: dateOnly,
                                                 isDST: dstFlag,
                                                 timezoneName: timeZoneID,
                                                 bufferMins: offset,
                                                 gmt: gmtOffsetHours))
                    }
                }
            }
        }
        return records
    }
}

// MARK: - CSV Handling
extension CSVReportsViewController {
    private func csvEscape(_ s: String) -> String {
        let escaped = s.replacingOccurrences(of: "\"", with: "\"\"")
        return "\"\(escaped)\""
    }
    
    func generateCSV(from records: [DSTRecord]) -> String {
        var lines: [String] = []
        lines.append("Record Name,Local DateTime,UTC DateTime,Date,IsDST,Timezone,Buffer Mins,GMT")
        for r in records {
            let row = [
                csvEscape(r.recordName),
                csvEscape(r.dateTime),
                csvEscape(r.utcDateTime),
                csvEscape(r.date),
                csvEscape(r.isDST),
                csvEscape(r.timezoneName),
                csvEscape(String(r.bufferMins)),
                csvEscape(String(r.gmt))
            ].joined(separator: ",")
            lines.append(row)
        }
        return lines.joined(separator: "\n")
    }
    
    private func saveCSVFile(content: String, fileName: String) -> URL? {
        let fileURL = FileManager.default.temporaryDirectory.appendingPathComponent(fileName)
        
        do {
            try content.write(to: fileURL, atomically: true, encoding: .utf8)
            return fileURL
        } catch {
            print("Failed to save CSV file '\(fileName)':", error)
            return nil
        }
    }
    
    @objc private func generateButtonTapped() {
        let startYear = Int(startYearField.text ?? "") ?? 2025
        let endYear = Int(endYearField.text ?? "") ?? startYear
        guard startYear <= endYear else {
            let a = UIAlertController(title: "Error", message: "Start year must be <= End year", preferredStyle: .alert)
            a.addAction(UIAlertAction(title: "OK", style: .default))
            present(a, animated: true)
            return
        }
        
        let useAllZones = allZonesSwitch.isOn
        let zones = useAllZones ? [] : Array(selectedZones)
        let bufferValue = Int(bufferField.text ?? "2") ?? 2
        let bufferRange = -bufferValue...bufferValue
        
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self = self else {
                return
            }
            let records = self.generateDSTReport(for: startYear...endYear,
                                                 timeZoneIDs: zones,
                                                 allTimeZones: useAllZones,
                                                 buffer: bufferRange)
            let csv = self.generateCSV(from: records)
            guard let fileURL = self.saveCSVFile(content: csv, fileName: "DST_Report.csv") else {
                self.showError("Failed to write CSV")
                return
            }
            
            DispatchQueue.main.async {
                let activity = UIActivityViewController(activityItems: [fileURL], applicationActivities: nil)
                self.present(activity, animated: true)
            }
        }
    }
}

// MARK: - UITableViewDataSource
extension CSVReportsViewController {
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return 5
        }
        return 0
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell: SettingsTableViewCell = tableView.dequeueOptReusableCell(for: indexPath) else {
            return UITableViewCell()
        }
        switch (indexPath.section, indexPath.row) {
        case (0, 0):
            cell.setupCell(primaryText: "Start Year", accessoryView: startYearField)
            cell.selectionStyle = .none
            return cell
            
        case (0, 1):
            cell.setupCell(primaryText: "End Year", accessoryView: endYearField)
            cell.selectionStyle = .none
            return cell
            
        case (0, 2):
            cell.setupCell(primaryText: "Buffer Minutes Range", accessoryView: bufferField)
            cell.selectionStyle = .none
            return cell
            
        case (0, 3):
            let secondaryText = allZonesSwitch.isOn ? "All \(allZones.count) timezones included" : "\(selectedZones.count) of \(allZones.count) timezones selected"
            cell.setupCell(primaryText: "All Timezones", secondaryText: secondaryText, accessoryView: allZonesSwitch)
            cell.selectionStyle = .none
            return cell
            
        case (0, 4):
            cell.setupCell(primaryText: "Select Time Zones")
            cell.accessoryType = .disclosureIndicator
            return cell
            
        default:
            return UITableViewCell()
        }
    }
}

// MARK: - UITableViewDelegate
extension CSVReportsViewController {
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if indexPath.row == 4 && indexPath.section == 0 {
            presentTimeZoneSelection()
        }
    }
    
    override func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        if section == 0 {
            let footer = UIView(frame: CGRect(x: 0, y: 0, width: tableView.bounds.width, height: 100))
            footer.backgroundColor = .clear
            let btn = UIButton(type: .system)
            btn.setTitle("Generate Report", for: .normal)
            btn.setTitleColor(.white, for: .normal)
            btn.backgroundColor = .systemBlue
            btn.layer.cornerRadius = 10
            btn.translatesAutoresizingMaskIntoConstraints = false
            btn.addTarget(self, action: #selector(generateButtonTapped), for: .touchUpInside)
            footer.addSubview(btn)
            NSLayoutConstraint.activate([
                btn.leadingAnchor.constraint(equalTo: footer.leadingAnchor, constant: 16),
                btn.trailingAnchor.constraint(equalTo: footer.trailingAnchor, constant: -16),
                btn.topAnchor.constraint(equalTo: footer.topAnchor, constant: 12),
                btn.heightAnchor.constraint(equalToConstant: 50)
            ])
            return footer
        }
        return nil
    }
    
    override func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 60
    }
    
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = TableSectionHeaderView(titleTextColor: UIColor.gray.withAlphaComponent(0.5), bgColor: .clear, padding: UIEdgeInsets(top: 5, left: 15, bottom: 8, right: 15), titleFont: UIFont.systemFont(ofSize: 10))
        if section == 0 {
            headerView.titleLabel.text = "Daylight Savings Time (DST)"
        }
        return headerView
    }
    
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 48
    }
}

// MARK: - TimeZoneSelectionDelegate
extension CSVReportsViewController: TimeZoneSelectionDelegate {
    func timeZoneSelectionDidComplete(selectedZones: [String]) {
        self.selectedZones = Set(selectedZones)
        tableView.reloadRows(at: [IndexPath(row: 3, section: 0)], with: .none)
    }
}


public class SettingsTableViewCell: UITableViewCell {
    static let reuseIdentifier = "SettingsTableViewCell"
    
    public var cellSelected = false {
        didSet {
            if let view = customAccessoryView as? UIButton {
                view.isSelected = cellSelected
            }
        }
    }
    
    func setupConstraints() {
        setupImageView()
        setupContent()
    }
    
    private func setupImageView() {
        contentView.addSubview(customImageView)
        customImageView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            customImageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            customImageView.topAnchor.constraint(greaterThanOrEqualTo: contentView.topAnchor, constant: 16),
            customImageView.bottomAnchor.constraint(lessThanOrEqualTo: contentView.bottomAnchor, constant: -16)
        ])
    }
    
    private var contentStackTrailing: NSLayoutConstraint?
    
    private func setupContent() {
        contentView.addSubview(contentStack)
        contentStack.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            contentStack.leadingAnchor.constraint(equalTo: customImageView.trailingAnchor),
            contentStack.topAnchor.constraint(greaterThanOrEqualTo: contentView.topAnchor, constant: 16),
            contentStack.bottomAnchor.constraint(lessThanOrEqualTo: contentView.bottomAnchor, constant: -16),
            contentStack.centerYAnchor.constraint(equalTo: customImageView.centerYAnchor)
        ])
        
        contentStackTrailing?.isActive = false
        contentStackTrailing = contentStack.trailingAnchor.constraint(lessThanOrEqualTo: contentView.trailingAnchor, constant: -16)
        contentStackTrailing?.isActive = true
    }
    
    private func setupAccessoryView() {
        guard let customAccessoryView else {
            return
        }
        contentView.addSubview(customAccessoryView)
        customAccessoryView.translatesAutoresizingMaskIntoConstraints = false
        if let view = customAccessoryView as? UIButton {
            view.isSelected = cellSelected
        }
        NSLayoutConstraint.activate([
            customAccessoryView.centerYAnchor.constraint(equalTo: contentStack.centerYAnchor),
            customAccessoryView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            customAccessoryView.bottomAnchor.constraint(lessThanOrEqualTo: contentView.bottomAnchor, constant: -16),
            customAccessoryView.topAnchor.constraint(greaterThanOrEqualTo: contentView.topAnchor, constant: 16),
            customAccessoryView.widthAnchor.constraint(lessThanOrEqualTo: contentView.widthAnchor, multiplier: 0.50)
        ])
        
        contentStackTrailing?.isActive = false
        contentStackTrailing = contentStack.trailingAnchor.constraint(lessThanOrEqualTo: customAccessoryView.leadingAnchor, constant: -16)
        contentStackTrailing?.isActive = true
    }
 
    lazy var contentStack = {
        let stack = UIStackView(arrangedSubviews: [primaryTextLabel])
        stack.alignment = .leading
        stack.axis = .vertical
        stack.spacing = 5
        stack.distribution = .fillProportionally
        return stack
    }()
    
    lazy var primaryTextLabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.adjustsFontForContentSizeCategory = true
        return label
    }()
    
    lazy var secondaryTextLabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.adjustsFontForContentSizeCategory = true
        return label
    }()
    
    private lazy var warningIcon = {
        let imageView = UIImageView()
        imageView.tintColor = UIColor.red
        imageView.contentMode = .scaleAspectFit
        NSLayoutConstraint.activate([
            imageView.widthAnchor.constraint(equalToConstant: 24),
            imageView.heightAnchor.constraint(equalToConstant: 24)
        ])
        return imageView
    }()
    
    lazy var secondaryTextStack = {
        let stackView = UIStackView(arrangedSubviews: [secondaryTextLabel])
        stackView.axis = .horizontal
        stackView.spacing = 2
        return stackView
    }()
    
    lazy var customImageView = UIView()
    
    var customAccessoryView: UIView?
    
    func setupCell(primaryText: String, secondaryText: String? = nil, secondaryTextAsWarning: Bool = false, accessoryView: UIView? = nil, imageView: UIImageView? = nil, configuration: SettingsCellConfiguration? = SettingsCellConfiguration.defaultConfiguration) {
        customAccessoryView?.removeFromSuperview()
        customImageView.subviews.forEach { view in
            view.removeFromSuperview()
        }
        primaryTextLabel.text = primaryText
        secondaryTextLabel.text = secondaryText
        if let imageView {
            customImageView.addSubview(imageView)
            imageView.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                imageView.leadingAnchor.constraint(equalTo: customImageView.leadingAnchor, constant: 8),
                imageView.widthAnchor.constraint(equalToConstant: 24),
                imageView.heightAnchor.constraint(equalToConstant: 24),
                imageView.centerYAnchor.constraint(equalTo: customImageView.centerYAnchor),
                imageView.trailingAnchor.constraint(equalTo: customImageView.trailingAnchor, constant: -8)
            ])
        }
        setupConstraints()
        if let accessoryView {
            customAccessoryView = accessoryView
            setupAccessoryView()
        }
        
        if secondaryTextAsWarning && secondaryText != nil {
            secondaryTextStack.insertArrangedSubview(warningIcon, at: 0)
        } else {
            warningIcon.removeFromSuperview()
        }
        
        if secondaryText != nil {
            contentStack.addArrangedSubview(secondaryTextStack)
        } else {
            secondaryTextStack.removeFromSuperview()
        }
        setupCellConfiguration(configuration!)
    }
    
    func setupCellConfiguration(_ configuration: SettingsCellConfiguration) {
        primaryTextLabel.textColor = configuration.primaryTextColor
        primaryTextLabel.highlightedTextColor = configuration.primaryTextHighlightColor
        contentView.tintColor = configuration.contentViewTintColor
    }
}

struct SettingsCellConfiguration {
    var primaryTextColor: UIColor
    var primaryTextHighlightColor: UIColor
    var contentViewTintColor: UIColor?
    var primaryTextFont: UIFont = UIFont()
    
    static let defaultConfiguration: SettingsCellConfiguration = SettingsCellConfiguration(primaryTextColor: UIColor(red: 10, green: 10, blue: 10, alpha: 0.5), primaryTextHighlightColor: UIColor(red: 10, green: 10, blue: 10, alpha: 0.2), contentViewTintColor: UIColor(red: 10, green: 10, blue: 10, alpha: 0.1), primaryTextFont: UIFont())
}

protocol ReusableView: AnyObject {}

extension ReusableView where Self: UIView {
    static var reuseIdentifier: String {
        return String(describing: self)
    }
}

extension UITableViewCell: ReusableView {}

extension UITableView {
    func dequeueOptReusableCell<T: UITableViewCell>(for indexPath: IndexPath) -> T? {
        return dequeueReusableCell(withIdentifier: T.reuseIdentifier, for: indexPath) as? T
    }
}
