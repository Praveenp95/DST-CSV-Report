import UIKit

class TableSectionHeaderView: UIView {
    
    private let titleTextColor: UIColor
    var bgColor: UIColor
    var padding: UIEdgeInsets {
        didSet {
            topConstraint.constant = padding.top
            bottomConstraint.constant = -padding.bottom
            leadingConstraint.constant = padding.left
            trailingConstraint.constant = -padding.right
        }
    }
    private let titleFont: UIFont
    
    @objc lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.font = titleFont
        label.textColor = titleTextColor
        label.numberOfLines = 0
        label.lineBreakMode = .byWordWrapping
        label.adjustsFontForContentSizeCategory = true
        return label
    }()
    
    @objc init(titleTextColor: UIColor, bgColor: UIColor, padding: UIEdgeInsets, titleFont: UIFont) {
        self.titleTextColor = titleTextColor
        self.bgColor = bgColor
        self.padding = padding
        self.titleFont = titleFont
        super.init(frame: .zero)
        addAndAlignViews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private lazy var topConstraint = titleLabel.topAnchor.constraint(equalTo: topAnchor, constant: padding.top)
    private lazy var bottomConstraint = titleLabel.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -padding.bottom)
    private lazy var leadingConstraint = titleLabel.leadingAnchor.constraint(equalTo: leadingAnchor, constant: padding.left)
    private lazy var trailingConstraint = titleLabel.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -padding.right)
    
    func addAndAlignViews() {
        self.backgroundColor = bgColor
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        addSubview(titleLabel)
        NSLayoutConstraint.activate([
            topConstraint,
            bottomConstraint,
            leadingConstraint,
            trailingConstraint
        ])
    }
}
